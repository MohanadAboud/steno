audioSource.src = "audio/voicebooking-speech.mp3"; // Test if this file is playing
audioElement.load();
audioElement.play();
